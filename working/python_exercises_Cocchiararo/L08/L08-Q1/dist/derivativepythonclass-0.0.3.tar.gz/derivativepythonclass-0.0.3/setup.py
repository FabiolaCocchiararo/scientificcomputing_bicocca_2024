from setuptools import setup, find_packages

setup(name='derivativepythonclass',
      description='test module for the python class',
      url='https://github.com/FabiolaCocchiararo',
      author='Fabiola Cocchiararo',
      author_email='f.cocchiararo@campus.unimib.it',
      license='MIT',
      version='0.0.3',
      packages=find_packages(),
      install_requires=['numpy'])
