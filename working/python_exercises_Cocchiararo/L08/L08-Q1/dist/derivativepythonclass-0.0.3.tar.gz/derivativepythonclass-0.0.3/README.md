Test upload package python - derivative function 
